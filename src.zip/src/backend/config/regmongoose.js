const mongoose = require('mongoose');

module.exports = {
    url: 'mongodb://localhost:27017/user_details' 
  
    };