const express = require('express');
const router = express.Router();
const cart_controller = require('../controller/cartcontroller');



router.get('/test', cart_controller.test);

router.post('/cartcreate', cart_controller.cart_create);

// router.post('/adminlogin',user_controller.user_adminlogin);

// router.post('/login',user_controller.user_login);

 router.get('/cartlist',cart_controller.cart_getall);

 router.get('/:id/get', cart_controller.cart_details);

// router.put('/update/:id', user_controller.user_update);

 router.delete('/:id/delete', cart_controller.cart_itemdelete);

module.exports = router;

