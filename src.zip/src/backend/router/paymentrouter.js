const express = require('express');
const router = express.Router();
const payment_controller = require('../controller/paymentcontroller');



router.get('/test', payment_controller.test);

router.post('/paymentcreate', payment_controller.payment_create);

// router.post('/adminlogin',user_controller.user_adminlogin);

// router.post('/login',user_controller.user_login);

 //router.get('/cartlist',cart_controller.cart_getall);

// router.get('/:id', user_controller.user_details);

// router.put('/update/:id', user_controller.user_update);

 //router.delete('/delete/:id', cart_controller.cart_delete);

module.exports = router;

