const express = require('express');
const router = express.Router();
const product_controller = require('../controller/productcontroller');



router.get('/test', product_controller.test);

router.post('/productcreate', product_controller.product_create);

// router.post('/adminlogin',user_controller.user_adminlogin);

// router.post('/login',user_controller.user_login);

 router.get('/productlist',product_controller.product_getall);

// router.get('/:id', user_controller.user_details);

// router.put('/update/:id', user_controller.user_update);

// router.delete('/delete/:id', user_controller.user_delete);

module.exports = router;

