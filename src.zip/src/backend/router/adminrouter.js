const express = require('express');
const router = express.Router();
const admin_controller = require('../controller/admincontroller');


router.post('/adminlogin',admin_controller.admin_adminlogin);

router.get('/test', admin_controller.test);

router.post('/admincreate', admin_controller.admin_create);



// router.post('/login',user_controller.user_login);

 //router.get('/getall',admin_controller.admin_getall);

// router.get('/:id', user_controller.user_details);

// router.put('/update/:id', user_controller.user_update);

// router.delete('/delete/:id', user_controller.user_delete);

module.exports = router;

