const express = require('express');
const router = express.Router();
const coupon_controller = require('../controller/couponcontroller');



router.get('/test', coupon_controller.test);

router.post('/couponcreate', coupon_controller.coupon_create);

// router.post('/adminlogin',user_controller.user_adminlogin);

 router.post('/couponcode',coupon_controller.coupon_couponcode);

 router.get('/couponlist',coupon_controller.coupon_getall);

// router.get('/:id', user_controller.user_details);

// router.put('/update/:id', user_controller.user_update);

// router.delete('/delete/:id', user_controller.user_delete);

module.exports = router;

