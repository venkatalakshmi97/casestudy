const Cart = require('../models/cartmodel');

exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

exports.cart_create = function (req, res,next) {
    // console.log(req);
    let cart = new Cart(
        {
            username:req.body.username,
            image: req.body.image,
            productid: req.body.productid,
            productname: req.body.productname,
            price: req.body.price,
            producttype: req.body.producttype
        
        }
    );

    cart.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Created successfully')
    })
};

exports.cart_getall = function (req, res) {
    Cart.find({}, function (err, cart) {
        if (err) console.log(err);
        else{
            res.status(200).send(cart)
        }
    })
};
exports.cart_details = function (req, res) {
    console.log(req.param);
    Cart.findById(req.param.id, function (err, cart) {
        if (err) console.log(err);
        else{
            res.status(200).send(cart)
        }
    })
};
// exports.cart_itemdelete = function (req, res,next) {
//     console.log(req.body);

//     Cart.findByIdAndRemove({_id: req.body}, function (err, cart) {
//         if (err) return next(err);
//         else{
//             res.status(200).send(cart)
//         }
//     })
    
//};
exports.cart_itemdelete = function (req, res,next) {
    Cart.findByIdAndRemove(req.params.id, function (error,cart) {
        // if (err) return next(err);
        if(error){
            console.log(error)
          }
          
             else{
                 res.status(200).send(cart)
             }
       // res.send('Deleted successfully!');
    })
};

