const Product = require('../models/productmodel');

exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

exports.product_create = function (req, res,next) {
    // console.log(req);
    let product = new Product(
        {
            producttype:req.body.producttype,
            image: req.body.image,
            productid: req.body.productid,
            productname: req.body.productname,
            price: req.body.price
        
        }
    );

    product.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Created successfully')
    })
};

exports.product_getall = function (req, res,next) {
    Product.find({}, function (err, product) {
        if (err) return next(err);
        res.send(product);
    })
};


