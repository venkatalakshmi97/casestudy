const User = require('../models/regmodel');

exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

exports.user_create = function (req, res,next) {
    // console.log(req);
    let user = new User(
        {
            
            username : req.body.username,
            email : req.body.email,
            mobilenumber: req.body.mobilenumber, 
            password:req.body.password
            
        }
    );

    user.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Created successfully')
    })
};

 
// exports.user_adminlogin = function (req, res,next) {
//     User.find({}, function (err, user) {
//         if(user.username==req.body.username){
//             req.send(req.body.username);
//         }
//         if (err) return next(err);
//         res.send(user.username);
//     })
// };

exports.user_adminlogin = function (req, res) {
    let user=req.body

    User.findOne({username: user.username},(error, user)=>{
      if(error){
        console.log(error)
      }
      else{
        if(!user){
            res.status(401).send('Invalid username')
        }else
         if(user.password !== user.password){
            res.status(401).send('Invalid password')
         } 
         else{
             res.status(200).send(user)
         }
     }
    }) 
    
    
}


exports.user_login = function (req, res) {
    let user=req.body

    User.findOne({username: user.username},(error, user)=>{
      if(error){
        console.log(error)
      }
      else{
        if(!user){
            res.status(401).send('Invalid username')
        }else
         if(user.password !== user.password){
            res.status(401).send('Invalid password')
         } 
         else{
             res.status(200).send(user)
         }
     }
    }) 
    
    
}

exports.user_getall = function (req, res,next) {
    User.find({}, function (err, user) {
        if (err) return next(err);
        res.send(user);
    })
};

//GETS A SINGLE USER FROM THE DATABASE
exports.user_details = function (req, res,next) {
    User.findById(req.params.id, function (err, user) {
        if (err) return next(err);
        res.send(user);
    })
};

exports.user_update = function (req, res,next) {
    User.findByIdAndUpdate(req.params.id, {$set: req.body}, function (err, user) {
        if (err) return next(err);
        res.send('udpated.');
    });
};

exports.user_delete = function (req, res,next) {
    User.findByIdAndRemove(req.params.id, function (err) {
        if (err) return next(err);
        res.send('Deleted successfully!');
    })
};