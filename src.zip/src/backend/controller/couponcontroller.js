const Coupon = require('../models/couponmodel');

exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

exports.coupon_create = function (req, res,next) {
    // console.log(req);
    let coupon = new Coupon(
        {
            
            image : req.body.image,
            percentage: req.body.percentage,
            minimumpurchase:req.body. minimumpurchase,
            couponcode:req.body.couponcode
        }
    );

    coupon.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Created successfully')
    })
};

exports.coupon_getall = function (req, res,next) {
    Coupon.find({}, function (err, coupon) {
        if (err) return next(err);
        res.send(coupon);
    })
};




exports.coupon_couponcode = function (req, res) {
    let coupon=req.body

    Coupon.findOne({couponcode: coupon.couponcode},(error, coupon)=>{
      if(error){
        console.log(error)
      }
      else{
        if(!coupon){
            res.status(401).send('Invalid coupon')
        }
         else{
             res.status(200).send(coupon)
         }
     }
    }) 
    
    
}


