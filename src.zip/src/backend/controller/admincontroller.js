const Admin = require('../models/adminmodel');

exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

exports.admin_create = function (req, res,next) {
    // console.log(req);
    let admin = new Admin(
        {
            
            username : req.body.username,
           
            password:req.body.password
            
        }
    );

    admin.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Created successfully')
    })
};



exports.admin_adminlogin = function (req, res) {
    let admin=req.body

    Admin.findOne({username: admin.username},(error, admin)=>{
      if(error){
        console.log(error)
      }
      else{
        if(!admin){
            res.status(401).send('Invalid username')
        }else
         if(admin.password !== admin.password){
            res.status(401).send('Invalid password')
         } 
         else{
             res.status(200).send(admin)
         }
     }
    }) 
    
    
}


