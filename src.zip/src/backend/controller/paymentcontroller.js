const Payment = require('../models/paymentmodel');

exports.test = function (req, res) {
    res.send('Greetings from the Test controller!');
};

exports.payment_create = function (req, res,next) {
    // console.log(req);
    let payment = new Payment(
        {
   username:req.body.username,        
   fullname: req.body.fullname,
   email: req.body.email,
   address: req.body.address,
   city: req.body.city,
   state: req.body.state,
   zip: req.body.zip,
   nameoncard: req.body.nameoncard,
   cardnumber: req.body.cardnumber,
   expmonth: req.body.expmonth,
   expyear: req.body.expyear,
   cvv: req.body.cvv,
   totalamount: req.body.totalamount
  
        
        }
    );

    payment.save(function (err) {
        if (err) {
            return next(err);
        }
        res.send('Created successfully')
    })
};
