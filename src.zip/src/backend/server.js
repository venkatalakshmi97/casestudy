const express = require('express');
const bodyParser = require('body-parser');
const user = require('./router/regrouter');
const admin = require('./router/adminrouter');
const coupon=require('./router/couponrouter');
const product=require('./router/productrouter');
const cart=require('./router/cartrouter');
const payment=require('./router/paymentrouter');
const app = express();
const morgan = require('morgan');
app.use(morgan("dev"));

const cors=require('cors');
app.use(cors())

const config = require('./config/regmongoose.js');
var mongoose = require('mongoose');

mongoose.Promise = global.Promise;

mongoose.connect(config.url, {
    useNewUrlParser: true
}).then(() => {
    console.log("Successfully connected to the database");    
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use('/users', user);
app.use('/admins', admin);
app.use('/coupons', coupon);
app.use('/product', product);
app.use('/cart', cart);
app.use('/payment', payment);


let port = 8000;
app.listen(port, () => {
    console.log('Server is up and running on port number ' + port);
});