const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let CartSchema = new Schema({

  

    username:String,
    image: String,
   productid: String,
    productname: String,
    price: Number,
    producttype: String

  
   
});




module.exports = mongoose.model('Cart', CartSchema);
