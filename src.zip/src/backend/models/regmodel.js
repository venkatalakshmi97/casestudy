const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let UserSchema = new Schema({


    username: String,
    email: String,
    mobilenumber: Number,
    password: String

  
   
});




module.exports = mongoose.model('Users', UserSchema);
