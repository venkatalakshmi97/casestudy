const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let CouponSchema = new Schema({


    image: String,
    percentage: Number,
    minimumpurchase: Number,
    couponcode: String

  
   
});




module.exports = mongoose.model('Coupons', CouponSchema);
