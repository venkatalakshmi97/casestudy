const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let PaymentSchema = new Schema({
 
   username: String,
   fullname: String,
   email: String,
   address: String,
   city: String,
   state: String,
   zip: String,
   nameoncard: String,
   cardnumber: String,
   expmonth: String,
   expyear: String,
   cvv: String,
   totalamount: Number
  
   
});




module.exports = mongoose.model('Payment', PaymentSchema);