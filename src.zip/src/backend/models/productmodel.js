const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let ProductSchema = new Schema({

   producttype: String,
    image: String,
    productid: String,
    productname: String,
    price: Number

  
   
});




module.exports = mongoose.model('Product', ProductSchema);
