const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let AdminSchema = new Schema({


    username: String,
   
    password: String

  
   
});




module.exports = mongoose.model('Admins', AdminSchema);
