export class Paymentd{
    
    username:String;
    fullname: String;
   email: String;
   address: String;
   city: String;
   state: String;
   zip: String;
   nameoncard: String;
   cardnumber: String;
   expmonth: String;
   expyear: String;
   cvv: String;
   totalamount: Number;
}