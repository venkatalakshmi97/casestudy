export class UserAccount {
    username: string;
    email: string;
    mobilenumber: number;
    password: string;
    
  

}