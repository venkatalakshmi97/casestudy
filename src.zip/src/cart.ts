export class Cart {
    
    _id: String;
    username: String;
    producttype: String;
    image: String;
    productname: String;
    price: Number;
    productid: String;

  
}