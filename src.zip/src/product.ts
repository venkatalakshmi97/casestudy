export class Product {
    
    producttype: String;
    image: String;
    productid: String;
    productname: String;
    price: Number;

  
}