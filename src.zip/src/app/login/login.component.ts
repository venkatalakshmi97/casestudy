import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/UserService';
import { LoginAccount } from 'src/loginAccount';

import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 
  loginUserData={
   

  }

  constructor(private fb: FormBuilder,private route:Router,private service: UserService,private _auth: AuthService) { }
  loginAccount : LoginAccount=new LoginAccount();
  
  value:any;
  submitted:boolean=false;
  check: boolean = false;
  response:any;
  loginForm: FormGroup;
  
  
  
  ngOnInit() {
    this.loginForm=this.fb.group(
  {
    name: ['', [Validators.required,Validators.maxLength(20),Validators.minLength(3) ]],
  password:['',[Validators.required,Validators.maxLength(15),Validators.minLength(6)]]
  
  })}
  
  onLogin(){
    this.submitted=true;
    console.log(this.loginAccount)
   
     // this.service.validateUser(this.loginAccount)
     this._auth.loginUser(this.loginAccount)
      .subscribe((response) =>
      {
        if(response!=null)
        {
          localStorage.setItem('Role','customer');
          localStorage.setItem('uname',response['username']);
          
           
          this.route.navigateByUrl("home");
        }
        else{
          this.route.navigateByUrl("sign-up");
        }
        this.value=response;
        console.log("inresponse vale")
        console.log(this.value)
        this.service.userDetails(this.value);
  
        console.log(response), error => console.log(error)});
    
      console.log(this.loginAccount)
     
      
     }

}
