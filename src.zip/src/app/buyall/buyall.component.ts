import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { PaymentService } from 'src/paymentservice';
import { Coupon } from 'src/coupon';
import { Product } from 'src/product';
import { Paymentd } from 'src/paymentd';
import { UserService } from 'src/UserService';
import { AuthService } from '../auth.service';
import { Cart } from 'src/cart';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-buyall',
  templateUrl: './buyall.component.html',
  styleUrls: ['./buyall.component.css']
})
export class BuyallComponent implements OnInit {

  [x: string]: any;

  constructor(private fb: FormBuilder,private route:Router,private paymentservice:PaymentService,private userService:UserService,private _auth: AuthService) { }
  regForm: FormGroup;
  couForm: FormGroup;
  submitted:boolean=false;
  code=0;
  cart:Cart[];
  product:Product=new Product();
  coupon:Coupon=new Coupon();
result:any;
response:any;
paymentd:Paymentd=new Paymentd();
discount: any;
total=0;
check:boolean=true;
//total: Number;
   ngOnInit() {
     this.getCartDetails();
     this.couForm = this.fb.group({
      couponcode:['',[Validators.required]]
     })
    this.regForm = this.fb.group({
   
     fullname:['',[Validators.required,Validators.maxLength(20),Validators.minLength(3) ]],
     email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')]],
     address:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
     city:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
     state:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
     zip:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
     nameoncard:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
     cardnumber:['',[ Validators.required,Validators.maxLength(14),Validators.minLength(6)]],
     expmonth:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
     expyear:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
     cvv:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6)]]
 });

  }
  
  getCartDetails()
  {
    this._auth.cartlist().subscribe(data=>
      {
        this.cart= data as Cart[];
        for(let i of this.cart){
          this.l=+(i.price);
          this.total=this.total+this.l;
          this.rm=this.total;
          this.totalprice=this.total;
          
        }
        
      });
      
    // this.product= this._auth.buyitem();
  
    // this.totalprice=this.product.price;
    // this.rm=this.product.price;
  }

  
  onPayment(){
    this.paymentd.username=localStorage.getItem('uname');
    this.paymentd.totalamount=this.totalprice;
   
    this._auth.paymentadd(this.paymentd)
    .subscribe(
      res=>console.log(res),
      err=>console.log(err)
    )
 
  }
  couponapply(){
 this.check=false;
    this._auth.couponget(this.coupon)
      .subscribe((response) =>
      {
        if(response!=null)
        {
          this.per=response.percentage;
          this.total=this.rm;
          this.discount=this.total*(this.per/100);
          this.code=this.discount;
          this.totalprice=this.total-this.code;
          console.log(this.totalprice);
        }
        else{
          
        }
        });
    
  }
  couponremove(){
      this.check=true;
       this.coupon.couponcode=null;
       this.code=0;
       this.totalprice=this.rm;
  }


  
 
     
       readValue(){
        return localStorage.getItem('uname');
      }

}
