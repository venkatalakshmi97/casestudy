import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyallComponent } from './buyall.component';

describe('BuyallComponent', () => {
  let component: BuyallComponent;
  let fixture: ComponentFixture<BuyallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
