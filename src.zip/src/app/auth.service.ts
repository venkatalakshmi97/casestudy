import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from 'src/product';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _registerUrl="http://localhost:8000/users"
  private _adminloginUrl="http://localhost:8000/admins/adminlogin"
 // private _loginUrl="http://localhost:8000/users/login"
  private _couponUrl="http://localhost:8000/coupons"
  private _productUrl="http://localhost:8000/product/productlist"
  private _cartUrl="http://localhost:8000/cart"
  private _deleteUrl="http://localhost:8000/cart/delete"
  private _paymentUrl="http://localhost:8000/payment"

  product:Product=new Product();
  id: String;
  //var y: Number;
  constructor(private http: HttpClient) { }

  registerUser(user){
    return this.http.post<any>(`${this._registerUrl}`+`/create`,user)
  }
  adminloginUser(user){
    return this.http.post<any>(this._adminloginUrl,user)
  }
  loginUser(user){
    return this.http.post<any>(`${this._registerUrl}`+`/login`,user)
  }
  couponlist():Observable<any>{
    return this.http.get(`${this._couponUrl}`+`/couponlist`)
  }
  productlist():Observable<any>{
    return this.http.get(this._productUrl)
  }
  addcart(user){
    return this.http.post<any>(`${this._cartUrl}`+`/cartcreate`,user)
  }
  cartlist():Observable<any>{
    return this.http.get(`${this._cartUrl}`+`/cartlist`)
  }
  couponget(user){
    return this.http.post<any>(`${this._couponUrl}`+`/couponcode`,user)
  }
  deleteitem(id): Observable<any>
  {
      console.log(id);
      return this.http.delete<any>(`${this._cartUrl}`+`/${id}`+`/delete`)
     // return this.http.delete(`${this._deleteUrl}`,id)
  }
  buyitem(){
    this.id=localStorage.getItem('price');
    var y= +this.id;
    this.product.image=localStorage.getItem('image');    
    this.product.productname=localStorage.getItem('productname'); 
    this.product.price=y;
    this.product.producttype=localStorage.getItem('producttype');
    this.product.productid=localStorage.getItem('productid');
    return this.product;
  }
  paymentadd(user){
    return this.http.post<any>(`${this._paymentUrl}`+`/paymentcreate`,user)
  }
  
  
}
