import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/coupon';
import { AuthService } from '../auth.service';
//import {ClipboardModule} from '@angular/cdk/clipboard';

@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.css']
})
export class CouponsComponent implements OnInit {

  coupon: Coupon[];
  value: String;
  constructor(private _auth: AuthService) { }

  ngOnInit(): void {
    this.reloadData();
  }
check=false;
  reloadData(){
    this._auth.couponlist().subscribe(data=>
      {
        this.coupon= data as Coupon[];
      });
     // console.log(this.coupon);
  }
 
  CouponDisplay(code){
    this.check=true;
    localStorage.setItem('code',code);
  }
  readvalue(){
    this.value=localStorage.getItem('code');
    return localStorage.getItem('code');
  }
}
