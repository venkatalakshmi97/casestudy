import { Component, OnInit } from '@angular/core';
import { PaymentService } from 'src/paymentservice';
import { UserService } from 'src/UserService';
import { LoginAccount } from 'src/loginAccount';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Product } from 'src/product';
import { Cart } from 'src/cart';

@Component({
  selector: 'app-homeappliances',
  templateUrl: './homeappliances.component.html',
  styleUrls: ['./homeappliances.component.css']
})
export class HomeappliancesComponent implements OnInit {
  product: Product[];
  cart:Cart=new Cart();
  loginAccount:LoginAccount=new LoginAccount();
 
  constructor(private route: Router,private service:PaymentService,private userservice:UserService,private _auth: AuthService) 
  { }
result:any;
submitted:boolean=false;
buy:Product=new Product();
  ngOnInit() {
    localStorage.setItem('producttype','homeappliances');
    this.reloadData();
  }
  reloadData(){
    this._auth.productlist().subscribe(data=>
      {
        this.product= data as Product[];
      });
      console.log(this.product);
  }
  buyNow(product)
 {
 
  if(localStorage.getItem('uname')!= 'null'){
  localStorage.setItem('productname',product.productname);
  localStorage.setItem('price',product.price);
  localStorage.setItem('image',product.image);
  localStorage.setItem('producttype',product.producttype);
  localStorage.setItem('producid',product.productid);

this.buy=this._auth.buyitem();
 
  this.route.navigateByUrl("payment");
  
 }
 else{
  this.route.navigateByUrl("findbyage");
}
}
  OnCart(type,image,name,price)
  {

    if(localStorage.getItem('uname')!= 'null'){

    
    this.cart.username=localStorage.getItem('uname');
    this.cart.producttype=type;
    this.cart.image=image;
    this.cart.productname=name;
    this.cart.price=price;
    console.log(this.cart);
        this._auth.addcart(this.cart).subscribe(
          res=>console.log(res),
          err=>console.log(err)
        );
        this._auth.reloadcart();
}
else{
  this.route.navigateByUrl("findbyage");
 }
  }


}
