import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router : Router) { }
  ngOnInit(){}
  
  
  readValue(key)
{

//console.log(localStorage.getItem('Role'))
return localStorage.getItem('Role');
}
logout(){
  localStorage.setItem('Role','nothing');
  localStorage.setItem('code','nothing');
this.router.navigateByUrl('homepage');
}

}





