import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Cart } from 'src/cart';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  cart:Cart[];
  l:any;
  constructor(private router : Router,private _auth: AuthService) { }
  
  ngOnInit(){
    //this.getCartDetails();
    this._auth.getLoggedInName.subscribe(l => this.getCartDetails());
  }
  
  getCartDetails()
  {
    
  this._auth.cartlist().subscribe(data=>
    {
      this.cart= data as Cart[];
      this.l=0;
      for(let i of this.cart){
        if(i.username==localStorage.getItem('uname')){
      this.l=this.l+1;
     // console.log(this.l);
      }
     
    }
    }); 
    // window.location.reload();
 }
  
  readValue(key)
{

//console.log(localStorage.getItem('Role'))
return localStorage.getItem('Role');
}
logout(){
  localStorage.setItem('uname','null');
  localStorage.setItem('Role','nothing');
  localStorage.setItem('code','nothing');
this.router.navigateByUrl('home');
}

}





