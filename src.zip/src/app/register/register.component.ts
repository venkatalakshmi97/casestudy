import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/UserService';
import { UserAccount } from 'src/userAccount';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerUserData={
   

  }

  constructor(private fb: FormBuilder,private route:Router,private userService: UserService,private _auth: AuthService) {}
  regForm: FormGroup;
  submitted:boolean=false;
   response:any;
  userAccount:UserAccount=new UserAccount();
  ngOnInit() {

    this.regForm = this.fb.group({
      name: ['', [Validators.required,Validators.maxLength(20),Validators.minLength(3) ]],
      email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
      mobilenumber:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10)]],
      password:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ],
      confirmpassword:['', Validators.required ]
   });
  }
  check=false; 
  onRegiter(){
        // this.submitted=true;
        console.log(this.userAccount)
        // this.userService.createUser(this.userAccount)
        //    .subscribe((response) =>{ 
        //     this.response=response
        //     console.log(this.response.password)});
        //     this.route.navigateByUrl("findbyage");
        this._auth.registerUser(this.userAccount)
    .subscribe(
      res=>console.log(res),
      err=>console.log(err)
    )
        // this.route.navigateByUrl("findbyage");
         this.check=true;
     }

}
