import { Component, OnInit } from '@angular/core';
import { LoginAccount } from 'src/loginAccount';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PaymentService } from 'src/paymentservice';
import { UserService } from 'src/UserService';
import { Cart } from 'src/cart';
import { AuthService } from '../auth.service';
import { Product } from 'src/product';
import { Paymentd } from 'src/paymentd';
import { Coupon } from 'src/coupon';


@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  [x: string]: any;

  constructor(private fb: FormBuilder,private route:Router,private paymentservice:PaymentService,private userService:UserService,private _auth: AuthService) { }
  regForm: FormGroup;
  couForm: FormGroup;
  submitted:boolean=false;
  code=0;
  product:Product=new Product();
  coupon:Coupon=new Coupon();
result:any;
response:any;
paymentd:Paymentd=new Paymentd();
discount: any;
check:boolean=true;
//total: Number;
   ngOnInit() {
     this.getCartDetails();
     this.couForm = this.fb.group({
      couponcode:['',[Validators.required]]
     })
    this.regForm = this.fb.group({
   
     fullname:['',[Validators.required ]],
     email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')]],
     address:['',[ Validators.required]],
     city:['',[ Validators.required]],
     state:['',[ Validators.required]],
     zip:['',[ Validators.required]],
     nameoncard:['',[ Validators.required]],
     cardnumber:['',[ Validators.required]],
     expmonth:['',[ Validators.required]],
     expyear:['',[ Validators.required]],
     cvv:['',[ Validators.required]]











  });

  }
  
  getCartDetails()
  {
  
    this.product= this._auth.buyitem();
  
    this.totalprice=this.product.price;
    this.rm=this.product.price;
  
    
 }

  
  onPayment(){
    this.submitted=true;
    this.paymentd.username=localStorage.getItem('uname');
    this.paymentd.totalamount=this.totalprice;
    console.log(this.paymentd);
    this._auth.paymentadd(this.paymentd)
    .subscribe(
      res=>console.log(res),
      err=>console.log(err)
    )
 
  }
  couponapply(){
 this.check=false;
    this._auth.couponget(this.coupon)
      .subscribe((response) =>
      {
        if(response!=null)
        {
          this.per=response.percentage;
          this.total=this.rm;
          this.discount=this.total*(this.per/100);
          this.code=this.discount;
          this.totalprice=this.total-this.code;
          console.log(this.totalprice);
        }
        else{
          
        }
        });
    
  }
  couponremove(){
      this.check=true;
       this.coupon.couponcode=null;
       this.code=0;
       this.totalprice=this.rm;
  }


  
 
     
       readValue(){
        return localStorage.getItem('uname');
      }
}
