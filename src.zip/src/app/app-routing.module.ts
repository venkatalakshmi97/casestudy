import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { HomeComponent } from './home/home.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { HomeappliancesComponent } from './homeappliances/homeappliances.component';

import { ClothingComponent } from './clothing/clothing.component';
import { BooksComponent } from './books/books.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import { CouponsComponent } from './coupons/coupons.component';
import { BuyallComponent } from './buyall/buyall.component';
import { HeaderComponent } from './header/header.component';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'header', component: HeaderComponent },
  { path: 'add', component: RegisterComponent },
  { path: 'admin', component: AdminloginComponent },
  { path: 'findbyage', component: LoginComponent },
  { path: 'products', component: ProductsComponent },
  { path: 'electronics', component: ElectronicsComponent },
  { path: 'homeappliances', component: HomeappliancesComponent },
  { path: 'books', component: BooksComponent },
  { path: 'clothing', component: ClothingComponent },
  { path: 'cart', component: CartComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'coupons', component: CouponsComponent },
  { path: 'buyall', component:BuyallComponent },
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
