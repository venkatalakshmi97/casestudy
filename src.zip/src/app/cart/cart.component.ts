import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/UserService';
import { PaymentService } from 'src/paymentservice';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Cart } from 'src/cart';
import { Product } from 'src/product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  result:any;
  submitted=false;
  cart:Cart[];
  product:Product=new Product();
  constructor(private route:Router,private cartservice:PaymentService,private _auth: AuthService) { }

  ngOnInit() {
    this. getCartDetails();
    
  }
  getCartDetails()
  {
  this._auth.cartlist().subscribe(data=>
    {
      this.cart= data as Cart[];
    }); 
   
 }

 buyNow(cart)
 {
  console.log(cart);
  localStorage.setItem('productname',cart.productname);
  localStorage.setItem('price',cart.price);
  localStorage.setItem('image',cart.image);
  localStorage.setItem('producttype',cart.producttype);
  localStorage.setItem('producid',cart.productid);

this.product=this._auth.buyitem();
  //this.submitted=true;
  this.route.navigateByUrl("payment");
  
 }
 buyall(){

 }

 readValue(){
   return localStorage.getItem('uname');
 }
 delete(id){
  console.log(id._id);
  this._auth.deleteitem(id._id)
  .subscribe(
    (res)=>
    {
       this.getCartDetails();
    },
    
    err=>console.log()
  )
 }

}
