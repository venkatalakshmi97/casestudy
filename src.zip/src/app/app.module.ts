import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators, ReactiveFormsModule, FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { HttpClientModule } from '@angular/common/http';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { HomeappliancesComponent } from './homeappliances/homeappliances.component';

import { ClothingComponent } from './clothing/clothing.component';
import { BooksComponent } from './books/books.component';
import { PaymentComponent } from './payment/payment.component';
import { CartComponent } from './cart/cart.component';
import { AuthService } from './auth.service';
import { CouponsComponent } from './coupons/coupons.component';
import { BuyallComponent } from './buyall/buyall.component';

import {ClipboardModule} from '@angular/cdk/clipboard';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    RegisterComponent,
    AdminloginComponent,
    LoginComponent,
    ProductsComponent,
    ElectronicsComponent,
    HomeappliancesComponent,

    ClothingComponent,
    BooksComponent,
    PaymentComponent,
    CartComponent,
    CouponsComponent,
    BuyallComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ClipboardModule,
  

  ],
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
