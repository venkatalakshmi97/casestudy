export class LoginAccount
{
    username:string;
   /*  localStorage.getItem('uname'); */
    password:string;
    couponCode:number;
    nameOnCard: string;
  CardNumber: string;
  expMonth: string;
  expYear: string;
  cvv: string; 
    imageUrl:string;
    price:number;
    
}



