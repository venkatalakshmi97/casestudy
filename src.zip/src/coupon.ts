export class Coupon {
    
    
    image: String;
    percentage: Number;
    minimumpurchase: Number;
    couponcode: String;


}